let currentStep = 1;
const totalSteps = 3;
const form = document.getElementById('registrationForm');
const successMessage = document.getElementById('successMessage');
const termsCheckbox = document.getElementById('termsCheckbox');
const submitBtn = document.getElementById('submitBtn');

const birthDateInput = form.querySelector('input[name="birthDate"]');
const ageCategoryRangeInput = document.getElementById('ageCategoryRangeInput'); // New: hidden input
const categoryOptions = {
    '3k': document.querySelector('input[name="category"][value="3k"]').closest('.card-radio'),
    '5k': document.querySelector('input[name="category"][value="5k"]').closest('.card-radio'),
    '10k': document.querySelector('input[name="category"][value="10k"]').closest('.card-radio')
};

const AGE_CATEGORIES = [
    { min: 6, max: 11, displayLabel: "6 to 11 years of age", valueLabel: "6-11" },
    { min: 12, max: 14, displayLabel: "12 to 14 years of age", valueLabel: "12-14" },
    { min: 15, max: 17, displayLabel: "15 to 17 years of age", valueLabel: "15-17" },
    { min: 18, max: 30, displayLabel: "18 to 30 years of age", valueLabel: "18-30" },
    { min: 31, max: 40, displayLabel: "31 to 40 years of age", valueLabel: "31-40" },
    { min: 41, max: 50, displayLabel: "41 to 50 years of age", valueLabel: "41-50" },
    { min: 51, max: 60, displayLabel: "51 to 60 years of age", valueLabel: "51-60" },
    { min: 61, max: Infinity, displayLabel: "61 years of age & above", valueLabel: "61+" },
];

function getCategoryRange(age, forDisplay = true) {
    if (age < 6) return forDisplay ? "Not eligible to participate" : "";
    for (const category of AGE_CATEGORIES) {
        if (age >= category.min && age <= category.max) {
            return forDisplay ? category.displayLabel : category.valueLabel;
        }
    }
    return forDisplay ? "Not categorized" : "";
}

// New age calculation functions
function calculateChronologicalAge(birthDateString) {
    if (!birthDateString) return 0;
    const birthDate = new Date(birthDateString);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDifference = today.getMonth() - birthDate.getMonth();
    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age < 0 ? 0 : age;
}

function getDaysSinceLastBirthday(birthDateString) {
    if (!birthDateString) return null;
    const birthDate = new Date(birthDateString);
    const today = new Date();

    const lastBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
    if (lastBirthday > today) {
        lastBirthday.setFullYear(today.getFullYear() - 1);
    }
    
    const oneDay = 1000 * 60 * 60 * 24;
    return Math.floor((today.getTime() - lastBirthday.getTime()) / oneDay);
}


function getCategoryAge(birthDateString) {
    if (!birthDateString) return 0;
    const chronologicalAge = calculateChronologicalAge(birthDateString);
    const birthDate = new Date(birthDateString);
    const today = new Date();

    const lastBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
    if (lastBirthday > today) {
        lastBirthday.setFullYear(today.getFullYear() - 1);
    }
    
    const oneDay = 1000 * 60 * 60 * 24;
    // Use floor to get whole days
    const daysSinceBirthday = Math.floor((today.getTime() - lastBirthday.getTime()) / oneDay);

    if (daysSinceBirthday > 10) {
        return chronologicalAge + 1;
    } else {
        return chronologicalAge;
    }
}


function updateDistanceOptions() {
    if (!birthDateInput) return;
    const dobValue = birthDateInput.value;
    const chronologicalAge = calculateChronologicalAge(dobValue);
    const categoryAge = getCategoryAge(dobValue);
    const daysSinceBirthday = getDaysSinceLastBirthday(dobValue);
    const categoryDisplayLabel = getCategoryRange(categoryAge, true);  // For visible text
    const categoryValueLabel = getCategoryRange(categoryAge, false); // For hidden input

    const ageDisplay = document.getElementById('ageDisplay');
    const ageInfoContainer = document.getElementById('ageInfoContainer');

    if (ageDisplay && ageInfoContainer) {
        if (dobValue) {
            ageDisplay.innerHTML = `Your age is <strong>${chronologicalAge} years and ${daysSinceBirthday} days</strong>.<br>Your category is: <strong>${categoryDisplayLabel}</strong>.`;
            ageInfoContainer.style.display = 'block'; // Show the container
            if (ageCategoryRangeInput) {
                ageCategoryRangeInput.value = categoryValueLabel; // Set hidden input
            }
        } else {
            ageDisplay.innerHTML = ''; // Clear display
            ageInfoContainer.style.display = 'none'; // Hide the container
            if (ageCategoryRangeInput) {
                ageCategoryRangeInput.value = ''; // Clear hidden input
            }
        }
    }

    const selectedCategory = form.querySelector('input[name="category"]:checked');

    Object.values(categoryOptions).forEach(option => option.style.display = 'none');

    if (categoryAge === 0) { 
        if (selectedCategory) selectedCategory.checked = false;
        return;
    }

    // Show options based on CATEGORY age
    if (categoryAge >= 6) {
        categoryOptions['3k'].style.display = 'block';
    }
    if (categoryAge >= 12) {
        categoryOptions['5k'].style.display = 'block';
    }
    if (categoryAge >= 14) {
        categoryOptions['10k'].style.display = 'block';
    }

    if (selectedCategory && selectedCategory.closest('.card-radio').style.display === 'none') {
        selectedCategory.checked = false;
    }
}

if (birthDateInput) {
    birthDateInput.addEventListener('input', updateDistanceOptions);
    updateDistanceOptions(); // Initial call
}


function toggleMedicalRequirement(isRequired) {
    const textarea = document.getElementById('medicalDetail');
    if (isRequired) {
        textarea.setAttribute('required', 'required');
    } else {
        textarea.removeAttribute('required');
        textarea.classList.remove('input-error');
        document.getElementById('medical-detail-container').classList.remove('has-error');
    }
}

document.querySelectorAll('.numeric-only').forEach(input => {
    input.addEventListener('input', function() {
        this.value = this.value.replace(/[^0-9]/g, '');
    });
});

termsCheckbox.addEventListener('change', function() {
    submitBtn.disabled = !this.checked;
    submitBtn.style.opacity = this.checked ? '1' : '0.5';
    submitBtn.style.cursor = this.checked ? 'pointer' : 'not-allowed';
    if (this.checked) {
        document.getElementById('terms-group').classList.remove('has-error');
    }
});

function validateEmail(email) {
    const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return re.test(String(email).toLowerCase());
}

function validateStep(step) {
    const currentSection = document.getElementById(`step${step}`);
    const inputs = currentSection.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;

    currentSection.querySelectorAll('.has-error').forEach(el => el.classList.remove('has-error'));
    currentSection.querySelectorAll('.input-error').forEach(el => el.classList.remove('input-error'));

    inputs.forEach(input => {
        let inputValid = true;

        if (input.type === 'radio') {
            const groupName = input.name;
            if (currentSection.querySelector(`input[name="${groupName}"]`)) { 
                const checked = currentSection.querySelector(`input[name="${groupName}"]:checked`);
                if (!checked) {
                    inputValid = false;
                    const groupContainer = input.closest('#gender-group') ||
                                            input.closest('#category-group') ||
                                            input.closest('#experience-group') ||
                                            input.closest('#medical-group');
                    if (groupContainer) groupContainer.classList.add('has-error');
                }
            }
        } else if (input.type === 'email') {
            if (!validateEmail(input.value)) inputValid = false;
        } else if (input.name.toLowerCase().includes('phone')) {
            if (input.value.length !== 10) inputValid = false;
        
        } else if (input.name === 'birthDate') {
            if (!input.value.trim()) {
                inputValid = false;
            } else {
                const chronologicalAge = calculateChronologicalAge(input.value); // Use chronological age for validation
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                const dob = new Date(input.value);

                if (dob > today) {
                    input.nextElementSibling.textContent = 'Date of birth cannot be in the future.';
                    inputValid = false;
                } else if (chronologicalAge < 6) { // Minimum age check
                    input.nextElementSibling.textContent = 'You must be at least 6 years old to register.';
                    inputValid = false;
                } else {
                    input.nextElementSibling.textContent = 'Please enter a valid date of birth.';
                }
            }
        } else if (input.type === 'checkbox') {
            if (!input.checked) {
                inputValid = false;
                input.closest('#terms-group').classList.add('has-error');
            }
        } else if (!input.value.trim()) {
            inputValid = false;
        }

        if (!inputValid) {
            isValid = false;
            const fieldGroup = input.closest('.field-group');
            if (fieldGroup) {
                fieldGroup.classList.add('has-error');
            }
            
            // Add input-error for inputs that need it (text, email, etc.)
            if (input.type !== 'radio' && input.type !== 'checkbox' && input.type !== 'file') {
                 input.classList.add('input-error');
            }
        }
    });

    // Validate Coupon Code (Optional but must be 10 digits if entered)
    const couponInput = currentSection.querySelector('input[name="couponCode"]');
    if (couponInput && couponInput.value.trim() !== '') {
        if (couponInput.value.length !== 10) {
            isValid = false;
            const fieldGroup = couponInput.closest('.field-group');
            if (fieldGroup) fieldGroup.classList.add('has-error');
            couponInput.classList.add('input-error');
        }
    }

    return isValid;
}

window.nextStep = function(step) {
    if (validateStep(step)) {
        const currentEl = document.getElementById(`step${step}`);
        currentEl.classList.add('hidden-step');
        
        setTimeout(() => {
            currentStep = step + 1;
            const nextEl = document.getElementById(`step${currentStep}`);
            nextEl.classList.remove('hidden-step');
            updateProgress();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }, 300);
    }
};

window.prevStep = function(step) {
    const currentEl = document.getElementById(`step${step}`);
    currentEl.classList.add('hidden-step');
    
    setTimeout(() => {
        currentStep = step - 1;
        const prevEl = document.getElementById(`step${currentStep}`);
        prevEl.classList.remove('hidden-step');
        updateProgress();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 300);
};

form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (validateStep(3) && validateStep(2) && validateStep(1)) { // Re-validate all steps
        window.location.href = 'thank-you.html';
    }
});

function updateProgress() {
    const progress = ((currentStep - 1) / (totalSteps - 1)) * 100;
    document.getElementById('progress-bar').style.width = `${progress}%`;
    
    const stepItems = document.querySelectorAll('.step-item');
    stepItems.forEach((item, index) => {
        const stepNum = index + 1;
        const dot = item.querySelector('.step-dot');
        
        item.classList.remove('active');
        dot.classList.remove('active', 'completed');
        
        if (stepNum < currentStep) {
            dot.innerHTML = '✓';
            dot.classList.add('completed');
        } else if (stepNum === currentStep) {
            dot.innerHTML = stepNum;
            dot.classList.add('active');
            item.classList.add('active');
        } else {
            dot.innerHTML = stepNum;
        }
    });
}

form.addEventListener('input', (e) => {
    // Find the parent field-group and remove its error state
    const fieldGroup = e.target.closest('.field-group');
    if (fieldGroup && fieldGroup.classList.contains('has-error')) {
        fieldGroup.classList.remove('has-error');

        // Also attempt to remove .input-error from the visual element
        const inputElement = fieldGroup.querySelector('.input-error');
        if (inputElement) {
            inputElement.classList.remove('input-error');
        }
    }
});